"""
Authentication Routes - Register, Login, Google Sign-In
Traditional email/password authentication (no OTP)
"""
from flask import Blueprint, request, jsonify, current_app
from database import db
from models.user import User
from utils.auth import hash_password, verify_password, generate_token
from utils.validators import validate_email, validate_phone, validate_password, validate_name

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    phone = data.get('phone', '').strip()
    password = data.get('password', '')
    
    valid, error = validate_name(name)
    if not valid:
        return jsonify({'error': error}), 400
    
    if not validate_email(email):
        return jsonify({'error': 'Invalid email format'}), 400
    
    if not validate_phone(phone):
        return jsonify({'error': 'Invalid phone number (10 digits starting with 6-9)'}), 400
    
    valid, error = validate_password(password)
    if not valid:
        return jsonify({'error': error}), 400
    
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 409
    
    if User.query.filter_by(phone=phone).first():
        return jsonify({'error': 'Phone number already registered'}), 409
    
    user = User(
        name=name,
        email=email,
        phone=phone,
        password_hash=hash_password(password),
        country=data.get('country', 'India'),
        state=data.get('state', ''),
        city=data.get('city', ''),
        sports=','.join(data.get('sports', [])),
        credit_score=100,
        is_email_verified=True,
        is_verified=True
    )
    
    db.session.add(user)
    db.session.commit()
    
    token = generate_token(user.id)
    
    return jsonify({
        'message': 'Registration successful',
        'token': token,
        'user': user.to_dict(include_private=True)
    }), 201


@auth_bp.route('/login', methods=['POST'])
def login():
    """Login with email/phone and password"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    identifier = data.get('identifier', '').strip().lower()
    password = data.get('password', '')
    
    if not identifier or not password:
        return jsonify({'error': 'Email/phone and password required'}), 400
    
    user = User.query.filter(
        (User.email == identifier) | (User.phone == identifier)
    ).first()
    
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    if not user.password_hash:
        return jsonify({'error': 'This account uses Google Sign-In. Please sign in with Google.'}), 401
    
    if not verify_password(password, user.password_hash):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    token = generate_token(user.id)
    
    return jsonify({
        'message': 'Login successful',
        'token': token,
        'user': user.to_dict(include_private=True)
    })


# ─── Auth Info ───

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """Get current user from token"""
    auth_header = request.headers.get('Authorization')
    if not auth_header:
        return jsonify({'error': 'No token provided'}), 401
    
    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != 'bearer':
        return jsonify({'error': 'Invalid token format'}), 401
    
    from utils.auth import decode_token
    user_id = decode_token(parts[1])
    
    if not user_id:
        return jsonify({'error': 'Invalid token'}), 401
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'user': user.to_dict(include_private=True)
    })


# ─── Google Sign-In ───

@auth_bp.route('/google', methods=['POST'])
def google_signin():
    """Authenticate via Google Sign-In"""
    data = request.get_json()
    
    if not data or not data.get('credential'):
        return jsonify({'error': 'Google credential required'}), 400
    
    credential = data['credential']
    
    try:
        from google.oauth2 import id_token
        from google.auth.transport import requests as google_requests
        
        client_id = current_app.config.get('GOOGLE_CLIENT_ID')
        idinfo = id_token.verify_oauth2_token(
            credential,
            google_requests.Request(),
            client_id
        )
        
        google_id = idinfo['sub']
        email = idinfo.get('email', '')
        name = idinfo.get('name', '')
        picture = idinfo.get('picture', '')
        
        if not email:
            return jsonify({'error': 'Google account has no email'}), 400
        
    except ValueError as e:
        return jsonify({'error': f'Invalid Google token: {str(e)}'}), 401
    except Exception as e:
        return jsonify({'error': f'Google authentication failed: {str(e)}'}), 500
    
    user = User.query.filter_by(google_id=google_id).first()
    
    if not user:
        user = User.query.filter_by(email=email).first()
        if user:
            user.google_id = google_id
            if picture and not user.profile_picture:
                user.profile_picture = picture
        else:
            user = User(
                name=name,
                email=email,
                google_id=google_id,
                profile_picture=picture,
                is_verified=True,
                is_email_verified=True,
                credit_score=75
            )
            db.session.add(user)
    
    db.session.commit()
    
    token = generate_token(user.id)
    
    return jsonify({
        'message': 'Google sign-in successful',
        'token': token,
        'user': user.to_dict(include_private=True)
    })
